function vcvs(nd1,nd2,ni1,ni2,val)

global G C b;
d = size(G,1); % current size of the MNA
xr = d+1;      % new row/column
b(xr) = 0;     % add new row

G(xr,xr) = 0; % add new row/column
C(xr,xr) = 0;

if (nd1 ~= 0)
    G(nd1,xr) = 1;
    G(xr,nd1) = 1;
end
if (nd2 ~= 0)
    G(nd2,xr) = -1;
    G(xr,nd2) = -1;
end

if (ni1 ~= 0)
    G(xr,ni1) = G(xr,ni1)-val;
end
if (ni2 ~= 0)
    G(xr,ni2) = G(xr,ni2)+val;
end