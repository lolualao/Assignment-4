function [U,time] = inputsig(type)
time = linspace(0,1,1000);

    for n=1:numel(time)
        t = time(n);
        
        if (type==1) %Type 1: Step
            if t<0.03
                U(n) = 0;
            else
                U(n) = 1;
            end

        elseif (type==2) %Type 2: sin(2pift)
            f = 1/0.03;
            U(n) = sin(2*pi*f*t);

        else %Type 3: Gaussian Pulse

            U(n) = makedist('Normal','mu',0.06,'sigma',0.03);
        end
        
    end
    

    

end

